﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zoldseges_app
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private double paradicsomkg = 1.10; //paradicsom ára/kg
        private double paprikakg = 0.80; //paprika ára/kg
        private double kaposztakg = 1.80; //káposzta ára/kg


        //eredmény kiiratásának szövegei
        private string eredmenyuzenet = "Összesen: ";
        private string eurojel = "€";

        private void button1_Click(object sender, EventArgs e)
        {
            //Számítás elvégzése
            double paradicsomok = (paradicsomkg * Convert.ToDouble(paradicsombox.Text));
            double paprikak = (paprikakg * Convert.ToDouble(paprikabox.Text));
            double kaposztak = (kaposztakg * Convert.ToDouble(kaposztabox.Text));

            double eredmenyosszesen = paradicsomok + paprikak + kaposztak;


            //Eredmény kiiratása
            eredmenylbl.Text = eredmenyuzenet + eredmenyosszesen + eurojel;

        }
    }
}
